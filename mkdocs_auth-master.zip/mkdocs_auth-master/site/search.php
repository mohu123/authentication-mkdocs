<?php
$users = array('admin' => 'hahahaha');
require_once('./basic_auth.php');
?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="en" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en" > <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <meta name="author" content="ACME">
  <link rel="shortcut icon" href="./img/favicon.ico">
  <title>Mkdocs_Auth</title>
  <link href='https://fonts.googleapis.com/css?family=Lato:400,700|Roboto+Slab:400,700|Inconsolata:400,700' rel='stylesheet' type='text/css'>

  <link rel="stylesheet" href="./css/theme.css" type="text/css" />
  <link rel="stylesheet" href="./css/theme_extra.css" type="text/css" />
  <link rel="stylesheet" href="./css/highlight.css">
  
  <script src="./js/jquery-2.1.1.min.js"></script>
  <script src="./js/modernizr-2.8.3.min.js"></script>
  <script type="text/javascript" src="./js/highlight.pack.js"></script>
  <script>var base_url = '.';</script>
  <script data-main="./mkdocs/js/search.js" src="./mkdocs/js/require.js"></script>

  
</head>

<body class="wy-body-for-nav" role="document">

  <div class="wy-grid-for-nav">

    
    <nav data-toggle="wy-nav-shift" class="wy-nav-side stickynav">
      <div class="wy-side-nav-search">
        <a href="." class="icon icon-home"> Mkdocs_Auth</a>
        <div role="search">
  <form id ="rtd-search-form" class="wy-form" action="./search.php" method="get">
    <input type="text" name="q" placeholder="Search docs" />
  </form>
</div>
      </div>

      <div class="wy-menu wy-menu-vertical" data-spy="affix" role="navigation" aria-label="main navigation">
	<ul class="current">
	  
          
            <li class="toctree-l1">
		
    <a class="" href=".">Home</a>
	    </li>
          
            <li class="toctree-l1">
		
    <a class="" href="mkdocs/">Mkdocs</a>
	    </li>
          
        </ul>
      </div>
      &nbsp;
    </nav>

    <section data-toggle="wy-nav-shift" class="wy-nav-content-wrap">

      
      <nav class="wy-nav-top" role="navigation" aria-label="top navigation">
        <i data-toggle="wy-nav-top" class="fa fa-bars"></i>
        <a href=".">Mkdocs_Auth</a>
      </nav>

      
      <div class="wy-nav-content">
        <div class="rst-content">
          <div role="navigation" aria-label="breadcrumbs navigation">
  <ul class="wy-breadcrumbs">
    <li><a href=".">Docs</a> &raquo;</li>
    
    
    <li class="wy-breadcrumbs-aside">
      
    </li>
  </ul>
  <hr/>
</div>
          <div role="main">
            <div class="section">
              

  <h1 id="search">Search Results</h1>

  <form id="content_search" action="search.php">
    <span role="status" aria-live="polite" class="ui-helper-hidden-accessible"></span>
    <input name="q" id="mkdocs-search-query" type="text" class="search_input search-query ui-autocomplete-input" placeholder="Search the Docs" autocomplete="off" autofocus>
  </form>

  <div id="mkdocs-search-results" class="search-results">
    Searching...
  </div>


            </div>
          </div>
          <footer>
  

  <hr/>

  <div role="contentinfo">
    <!-- Copyright etc -->
    
  </div>

  Built with <a href="http://www.mkdocs.org">MkDocs</a> using a <a href="https://github.com/snide/sphinx_rtd_theme">theme</a> provided by <a href="https://readthedocs.org">Read the Docs</a>.
</footer>
	  
        </div>
      </div>

    </section>

  </div>

  <div class="rst-versions" role="note" style="cursor: pointer">
    <span class="rst-current-version" data-toggle="rst-current-version">
      
      
      
    </span>
</div>
    <script src="./js/theme.js"></script>

</body>
</html>
